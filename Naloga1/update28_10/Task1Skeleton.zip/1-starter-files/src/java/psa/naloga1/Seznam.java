package psa.naloga1;

public class Seznam {
	private NodeSeznam head;

	public Seznam(){
		this.head=null;
	}

	/*
	 * Metoda sprejme celo stevilo in ga vstavi v seznam. Ce element ze obstaja v seznamu, vrne false
	 * Metoda vrne true, ce je bil element uspesno vstavljen in false sicer.
	 */
	public boolean insert(int element) {
		NodeSeznam newElement = new NodeSeznam(element);

		if (this.getHead() == null){
			this.setHead(newElement);
			System.out.println("Insertion of " + element + " is completed");
			//this.getHead().incCounter();
			return true;
		}else {
			if (this.getHead().compare(newElement) == 0){
				return false;
			}else{
				return this.getHead().insert(newElement);
			}
		}
	}

	/*
	 * Metoda sprejme celo stevilo in izbrise element iz seznama. 
	 * Metoda vrne true, ce je bil element uspesno izbrisan iz seznama, in false sicer

	}*/

	public boolean delete(int element){
		NodeSeznam toBeDeleted = new NodeSeznam(element);

		if (this.getHead() == null){
			return false;
		}else {
			if (this.getHead().compare(toBeDeleted) == 0){   //if its the element to be deleted
				this.setHead(this.getHead().getRep());		//remove head...new head is olders head tail
				return true;
			}else {
				if (this.getHead().getRep() == null){		//if tail is null -> false
					return false;
				}else{
					return this.getHead().delete(toBeDeleted);
				}
			}
		}
	}

	/*
	 * Metoda sprejme celo stevilo in poisce element v seznamu. 
	 * Metoda vrne true, ce je bil element uspesno najden v seznamu, in false sicer
	 */
	public boolean search(int element) {
		NodeSeznam temp = new NodeSeznam(element);

		if (this.getHead() == null){
			return false;
		}
		else if (this.getHead().compare(temp) == 0){
			return true;
		}else{
			NodeSeznam current = head;
			while (current.getRep() != null){
				if (current.getRep().compare(temp) == 0){
					return true;
				}
				current=current.getRep();
			}
			return false;
		}
	}
	
	public int getCounter() {
		return head != null?head.getCounter():null;
	}
	
	public void resetCounter() {
		if(head!= null)
			head.resetCounter();
	}

	public NodeSeznam getHead() {
		return head;
	}

	public void setHead(NodeSeznam head) {
		this.head = head;
	}
}
