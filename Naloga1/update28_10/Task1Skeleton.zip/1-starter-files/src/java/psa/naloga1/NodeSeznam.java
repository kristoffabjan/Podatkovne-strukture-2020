package psa.naloga1;

public class NodeSeznam {
	private static int counter;
	private int key;
	private NodeSeznam rep;

	public NodeSeznam(int key){
		this.key = key;
		this.rep = null;
	}

	public boolean insert(NodeSeznam node){
		if (this.getRep() == null){
			this.setRep(node);
			System.out.println("Insertion of " + node.getKey() + " is completed.") ;
			//counter++;
			return true;
		}else {
			if (this.getRep().compare(node) == 0){
				return false;
			}else {
				return this.getRep().insert(node);
			}
		}
	}

	public boolean delete(NodeSeznam node){
		if(this.getRep() == null){
			return false;
		}else{
			if (this.getRep().compare(node) == 0){
				this.setRep(this.getRep().getRep());
				return true;
			}else{
				return this.getRep().delete(node);
			}
		}
	}
	
	public int compare(NodeSeznam node) {
		counter++;							//commented counter, bc it counts all comparisons
		return node.key - this.key;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void resetCounter() {
		counter=0;
	}

	public void setCounter(int counter) {
		NodeSeznam.counter = counter;
	}

	public void incCounter() {
		counter++;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public NodeSeznam getRep() {
		return rep;
	}

	public void setRep(NodeSeznam rep) {
		this.rep = rep;
	}
}
