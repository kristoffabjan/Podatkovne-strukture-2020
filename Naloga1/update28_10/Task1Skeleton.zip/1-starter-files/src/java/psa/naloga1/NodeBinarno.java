package psa.naloga1;

import org.w3c.dom.Node;

public class NodeBinarno {
	private static int counter;
	private int key;
	private NodeBinarno left;
	private NodeBinarno right;

	public NodeBinarno(int key){
		this.key = key;
		this.left = null;
		this.right = null;
	}

	public boolean insert(NodeBinarno node){
		if (this.getKey() > node.getKey()){		//if el. to be inserted is lower than root el -> to left
			if (this.getLeft() == null){
				this.setLeft(node);
				System.out.println("Node " + node.getKey() + " inserted.");
				return true;
			}else {
				if (this.getLeft().getKey() == node.getKey()){		//checking left child if its null or same as el. to
					return false;							//to be inserted,
				}else {										//else -> recursive call on left child
					return this.getLeft().insert(node);
				}
			}
		}else {							//if el to be inserted is bigger than parent -> go right
			if (this.getRight() == null){
				this.setRight(node);
				System.out.println("Node " + node.getKey() + " inserted.");
				return true;
			}else {
				if (this.getRight().getKey() == node.getKey()){		//checking left child if its null or same as el. to
					return false;							//to be inserted,
				}else {										//else -> recursive call on left child
					return this.getRight().insert(node);
				}
			}
		}
	}

	public boolean search(NodeBinarno node){

		if (this.getKey() > node.getKey()) {            //if searched el is smaller than root -> go left
			if (this.getLeft() == null){
				return false;
			}else {
				if (this.getLeft().compare(node) == 0){		//check if left child is equal to node
					return true;							//if so, true
				}else {										//else recursive call on left child
					return this.getLeft().search(node);
				}
			}
		}else {
			if (this.getRight() == null){
				return false;
			}else {
				if (this.getRight().compare(node) == 0){		//check if Right child is equal to node
					return true;							//if so, true
				}else {										//else recursive call on Right child
					return this.getRight().search(node);
				}
			}
		}
	}

	public boolean delete(NodeBinarno node){
		if (this.getKey() > node.getKey()){							//if node 2be deleted < root -> go left
			if (this.getLeft() == null){						//if null, el 2be deleted doesnt exist
				return false;
			}else {
				if (this.getLeft().compare(node) == 0){
					if (this.getLeft().getLeft() == null && this.getLeft().getRight() == null ){
						this.setLeft(null);							//if left child has no children
					}
					else if (this.getLeft().getLeft() != null && this.getLeft().getRight() == null ){
						this.setLeft(this.getLeft().getLeft());			//right empty -> left is new root
					}
					else {
						this.setLeft(this.getLeft().getRight().findMin());	//min in right is new root if left is null
					}
				}else {										//repeat on left child
					return this.getLeft().delete(node);
				}
			}
		}else {															//if 2be deleted is > root -> go right
			if (this.getRight() == null){						//if null, el 2be deleted doesnt exist
				return false;
			}else {
				if (this.getRight().compare(node) == 0){
					if (this.getRight().getLeft() == null && this.getRight().getRight() == null ){
						this.setRight(null);							//if left child has no children
					}
					else if (this.getRight().getLeft() != null && this.getRight().getRight() == null ){
						this.setRight(this.getRight().getLeft());			//right empty -> left is new root
					}
					else {
						this.setRight(this.getRight().getRight().findMin());	//min in right is new root if left is null
					}
				}else {										//repeat on left child
					return this.getRight().delete(node);
				}
			}
		}
		return true;
	}

	public NodeBinarno findMin(){									//mogoce manjkajo popravljene reference
		if (this.getRight() == null && this.getLeft() == null){		//no childre -> return root
			return this;
		}
		else if (this.getLeft() == null && this.getRight() != null){
			return this;												//if left is null, current is lowest
		}
		else {
			return this.getLeft().findMin();									//go further on left
		}

	}

	
	public int compare(NodeBinarno node) {
		counter++;
		return node.key - this.key;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void resetCounter() {
		counter=0;
	}

	public static void setCounter(int counter) {
		NodeBinarno.counter = counter;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public NodeBinarno getLeft() {
		return left;
	}

	public void setLeft(NodeBinarno left) {
		this.left = left;
	}

	public NodeBinarno getRight() {
		return right;
	}

	public void setRight(NodeBinarno right) {
		this.right = right;
	}
}
