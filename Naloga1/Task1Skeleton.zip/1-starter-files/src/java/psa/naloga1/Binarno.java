package psa.naloga1;

import org.w3c.dom.Node;

public class Binarno {
	private NodeBinarno root;

	public Binarno(){
		this.root = null;
	}

	/*
	 * Metoda sprejme celo stevilo in ga vstavi v drevo. Ce element ze obstaja v drevesu, vrne false
	 * Metoda vrne true, ce je bil element uspesno vstavljen in false sicer.
	 */
	public boolean insert(int element) {
		NodeBinarno newNode = new NodeBinarno(element);

		if (this.getRoot() == null){
			this.setRoot(newNode);
			System.out.println("Node " + newNode.getKey() + " inserted.");
			return true;
		}else {
			if (this.getRoot().compare(newNode) == 0){
				return false;
			}else {
				return this.getRoot().insert(newNode);
			}
		}
	}



	/*
	 * Metoda sprejme celo stevilo in izbrise element iz drevesa. 
	 * Metoda vrne true, ce je bil element uspesno izbrisan iz drevesa, in false sicer
	 */
	public boolean delete(int element) {
		NodeBinarno toBeDeleted = new NodeBinarno(element);
		if (this.getRoot() == null){
			return false;
		}else {
			if (this.getRoot().compare(toBeDeleted) == 0) {            //if root has to be deleted
				if (this.getRoot().getLeft() == null && this.getRoot().getRight() == null) {        //root w no children
					this.setRoot(null);
					return true;
				} else if (this.getRoot().getLeft() == null && this.getRoot().getRight() != null) {
					this.setRoot(this.getRoot().getRight());    //if left is null, right child is new root
					return true;
				} else if (this.getRoot().getLeft() != null && this.getRoot().getRight() == null) {
					this.setRoot(this.getRoot().getLeft());        //if right is null, left child is new root
					return true;
				} else {
					this.setRoot(this.getRoot().getRight().findMin());
					return true;
				}
			} else {
				return this.getRoot().delete(toBeDeleted);
			}
		}
	}



	/*
	 * Metoda sprejme celo stevilo in poisce element v drevesu. 
	 * Metoda vrne true, ce je bil element uspesno najden v drevesu, in false sicer
	 */
	public boolean search(int element) {
		NodeBinarno searchedElement = new NodeBinarno(element);

		if (this.getRoot() == null){
			return false;
		}else {
			if (this.getRoot().compare(searchedElement) == 0){			//if el = root.key
				return true;
			}else {
				return this.getRoot().search(searchedElement);
			}
		}

	}

	public int getCounter() {
		return root != null?root.getCounter():null;
	}
	
	public void resetCounter() {
		if(root!= null)
			root.resetCounter();
	}

	public NodeBinarno getRoot() {
		return root;
	}

	public void setRoot(NodeBinarno root) {
		this.root = root;
	}
}

