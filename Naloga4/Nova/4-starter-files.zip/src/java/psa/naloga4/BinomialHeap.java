package psa.naloga4;

import java.util.Vector;

public class BinomialHeap {
	BinomialNode[] data;
	
	BinomialHeap(){
		data = new BinomialNode[1];
	}
	
	public boolean insert(int key) {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
	
	public int getMin() {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
	
	public boolean delMin() {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
	
	private void resizeArray() {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
	
	private BinomialNode merge(BinomialNode t1, BinomialNode t2) {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
}

