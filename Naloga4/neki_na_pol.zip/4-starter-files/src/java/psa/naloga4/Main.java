package psa.naloga4;

public class Main {
    public static void main(String[] args) {
        BinomialHeap b = new BinomialHeap();
        System.out.println(b.data[0]);
        b.insert(7);
        b.insert(2);

        b.insert(8);
        //System.out.println(b.data[0].key + " tu je 2");
       // System.out.println(b.data[0].key);



    }
}
