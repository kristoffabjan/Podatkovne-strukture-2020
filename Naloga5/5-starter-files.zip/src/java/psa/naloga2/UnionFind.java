package psa.naloga2;


public class UnionFind {
	public int[] id;

	public UnionFind(int N) {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}

	/*
	 * Metoda sprejme index in vrne predstavnika mnozice, katere clan je index.
	 */
	public int find(int i) {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}

	/*
	 * Metoda sprejme da indexa in naredi unijo
	 */
	public void unite(int p, int q) {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
	
	/*
	 * Metoda vrne true, ce sta p in q v isti mnozici
	 */
	public boolean isInSameSet(int p, int q) {
		throw new UnsupportedOperationException("To funkcijo morate implementirati");
	}
}
